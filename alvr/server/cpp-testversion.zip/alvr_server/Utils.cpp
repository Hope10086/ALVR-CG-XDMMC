#include "Utils.h"

uint64_t gPerformanceCounterFrequency = 0;